"""
Eze version
"""

__version__ = "0.8.0-alpha"
